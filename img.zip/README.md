# chat
php-fusion chat created in php and JavaScript 


When the new chat is done this libery will be changed so it work self with out any freamworks. 
When it is done a small change every time would make it possible to use freamworks like phpbb and so on. 
Other change will be allowed to use other database system end MySQL
