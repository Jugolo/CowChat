<?php
$locale = array();
$locale["login_title"]          = "Login";
$locale["online_user"]          = "Online user";
$locale["login"]                = "Login";
$locale["username"]             = "Username";
$locale["password"]             = "Password";
$locale["re_password"]          = "Password again";
$locale["login_now"]            = "Login now";
$locale["create_account"]       = "Create account";
$locale["missing_username"]     = "Missing username";
$locale["missing_password"]     = "Missing password";
$locale["wrong_login"]          = "Wrong username and/or password";
$locale["missing_re_password"]  = "Missing repeat of password";
$locale["password_mismatch"]    = "The two password are not equel";
$locale["username_taken"]       = "Username is taken";

$locale["chat_index"]           = "Chat front page";
$locale["logout"]               = "Logout";