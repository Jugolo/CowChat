<?php
define("Yes",1);
define("No",2);